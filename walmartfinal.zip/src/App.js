import React from 'react'
import './App.css';
import Appbar from './Components/Appbar'
import Content from './Components/Content'
import {Box} from '@mui/material';
function App() {
  return (
    <div className="App">
      <Box sx={{display:"flex",flexDirection:"column"}}>
        <Appbar/>
        <Content/>
      </Box>
    </div>
  );
}

export default App;
