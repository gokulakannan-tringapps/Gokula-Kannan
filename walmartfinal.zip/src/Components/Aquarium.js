import { Box, Typography } from "@mui/material"
import Billings from "./Billings"

export default function Aquarium(){
    return(
        <Box sx={{bgcolor:"#50b397"}}>
        <Typography sx={{p:1,fontSize:30,fontWeight:"700"}}>Aquarium</Typography>
        <Billings/>
    </Box>
    )
}