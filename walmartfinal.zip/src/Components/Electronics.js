import { Typography } from "@mui/material"
import { Box } from "@mui/material"
import Billings from "./Billings"

export default function Electronics(){
    return(
        <Box sx={{bgcolor:"#c9d42c"}}>
            <Typography sx={{p:1,fontSize:30,fontWeight:"700"}}>Electronics</Typography>
            <Billings/>
        </Box>
    )
}