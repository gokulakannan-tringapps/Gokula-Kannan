import { TableHead } from '@mui/material'
import {Table,TableRow,TableBody,TableCell} from '@mui/material'

export default function Billings(){
    return(
        <Table>
            <TableHead >
            <TableRow >
                <TableCell > ProductId</TableCell>
                <TableCell > ProductName</TableCell>
                <TableCell > Quantity</TableCell>
                <TableCell > Price</TableCell>
                <TableCell > Total</TableCell>
            </TableRow>
            </TableHead>
        </Table>
    )
}