import { Typography } from '@mui/material';
import {Box} from '@mui/material';
import Electronics from './Electronics';
import Clothings from './Clothings';
import Aquarium from './Aquarium';

export default function Content(){
        return(
            <Box sx={{display:"flex",bgcolor:"#827d7a",p:2}}>
                    <Electronics/>
                    <Clothings/>
                    <Aquarium/>
            </Box>
        )
}