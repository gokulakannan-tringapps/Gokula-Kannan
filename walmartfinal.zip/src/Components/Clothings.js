import { Box, Typography } from "@mui/material"
import Billings from "./Billings"
export default function Clothings(){
    return(
        <Box sx={{bgcolor:"#c2551f"}}>
            <Typography sx={{p:1,fontSize:30,fontWeight:"700"}}>Clothings</Typography>
            <Billings/>
        </Box>
    )
}