import React from 'react'
import { Typography } from "@mui/material";
import { AppBar, Box, Toolbar, Avatar, Button } from "@mui/material";
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';
import CheckroomRoundedIcon from '@mui/icons-material/CheckroomRounded';
import SetMealRoundedIcon from '@mui/icons-material/SetMealRounded';
import Purchase from "./Purchase";

export default function Appbar(){
    
    const [open, setOpen]=React.useState(false)

    const handleOpen = () =>{
        setOpen(true)
    }
    const handleClose = () =>{
        setOpen(false)
    }
    return(
        <Box >
            <AppBar position="static" sx={{p:3,bgcolor:"#313331", color:"#4aed1c", }}  >
                <Toolbar >
                    <Avatar sx={{p:1,fontSize:58,bgcolor:"white", color:"#313331", fontWeight:"700" }}>W</Avatar>
                    <Typography sx={{ml:2,fontWeight:"600", fontSize:45}} variant="h4" >WalMart Retail Store</Typography>
                    <Button variant="contained" onClick={handleOpen} sx={{color:"#313331",bgcolor:"#4aed1c",ml:15,fontSize:18,fontWeight:700}}><ElectricBoltIcon/>Electronics</Button>
                    <Button variant="contained" onClick={handleOpen} sx={{color:"#313331",bgcolor:"#4aed1c",ml:2,fontSize:18,fontWeight:700}}><CheckroomRoundedIcon/>Clothings</Button>
                    <Button variant="contained" onClick={handleOpen} sx={{color:"#313331",bgcolor:"#4aed1c",ml:2,fontSize:18,fontWeight:700}}><SetMealRoundedIcon/>Aquarium</Button>
                </Toolbar>
            </AppBar>
            <Purchase Status={open} Close={handleClose}/>
        </Box>
    )
}