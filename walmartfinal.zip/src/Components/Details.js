import React from 'react'
import { MenuItem } from '@mui/material'
import { FormControl, InputLabel, Select, Typography } from '@mui/material'
import {Box,Button} from '@mui/material'

export default function Details(){

    const [product, setProduct]=React.useState("")
    const [quantity, setQuantity]=React.useState("")
    const [status,setStatus]=React.useState(true)

    const handleProducts = (e) => {
        setProduct(e.target.value)
        setStatus(false)
    }

    const handleQuantity = (e) => {
        setQuantity(e.target.value)
    }
    return(
        <Box sx={{display:"flex",mt:2}}>
            <FormControl sx={{width:130}}>
                <InputLabel id="products">Products</InputLabel>
                <Select labelId="products" value={product} onChange={handleProducts} label="Products">
                    <MenuItem value={1}>biriyani</MenuItem>
                    <MenuItem value={2}>noodles</MenuItem>
                    <MenuItem value={3}>cake</MenuItem>
                </Select>
            </FormControl>
            <FormControl disabled={status} sx={{ml:2,width:130}}>
                <InputLabel id="quantity">Quantity</InputLabel>
                <Select labelId="quantity" value={quantity} onChange={handleQuantity} label="Quantity">
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={2}>2</MenuItem>
                    <MenuItem value={3}>3</MenuItem>
                </Select>
            </FormControl>  
            <Typography sx={{ml:2}}>PRICE = NA</Typography>
            <Typography sx={{ml:2}}>TOTAL = NA</Typography>
            <Button variant="contained" sx={{fontWeight:700,fontSize:25,ml:2}}>ADD</Button>
        </Box>
    )
}