import React from 'react'
import {Box,Dialog,DialogContent, DialogTitle,Button,DialogActions} from '@mui/material'
import Details from './Details'
export default function Purchase(props){

   
    return(
        
        <Dialog  open={props.Status} onClose={props.Close}>
            <DialogTitle>Products</DialogTitle>
            <DialogContent>
                        <Details/>
            </DialogContent>
            <DialogActions>
                <Button onClick={props.Close}>Buy</Button>
                <Button onClick={props.Close}>Cancel</Button>
            </DialogActions>
        </Dialog>
    
    )
}