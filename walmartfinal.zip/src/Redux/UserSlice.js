import  {CreateSlice} from '@reduxjs/toolkit'

const userSlice = CreateSlice({
    name:'walmart',
    initialState:{
        itemsList:[],
        quantityList:0,
        priceList:0,
        totalprice:0,
    },
    reducers:{
         addItems(state, action){
            const newItem = action.payload


            const existingItems = state.itemsList.find((item) => item.id === newItem.id)
            if(existingItems){
                existingItems.price++;
                existingItems.quantityList++;
                existingItems.priceList++;
                
            }  
         }
         deleteItems(state,action){

         }
    }
})