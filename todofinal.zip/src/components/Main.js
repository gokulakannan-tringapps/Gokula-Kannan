import React from 'react';
import { TextField, Button, Box, Typography } from '@mui/material';
import Todolist from './Todolist'
import {nanoid} from 'nanoid'



export default function Main(){
    const [input, setInput]=React.useState('')
    const [list, setList]=React.useState([])
    const [doneCount, setDoneCount]=React.useState(0)

    
    const handleChange = (e) =>{
        setInput(e.target.value)
    }

    const handleSubmit = () =>{
        let items ={
        id:nanoid(),
        text:input,
        flag:false,
        }
        let update = [...list, items]
        setList(update)
        setInput("")
    }

    function deleteList(id){
        let updateItem = list.filter(item => item.id !== id)
        setList(updateItem)
    }

    function countList(id){
      
        let count=0
        for(let i=0; i<list.length;i++)
        {
            if(list[i].id === id){
              list[i].flag=!list[i].flag
            }
            if(list[i].flag){
              count++
            }
        }
        setDoneCount(count)
      }

  const todolist = list.map( (item) => 
    <Todolist key={item.id} 
              text={item.text} 
              status={()=>countList(item.id)}
              delete={()=>deleteList(item.id)}
              doneCount={doneCount}
             />)
  
  return (
    <div className="Main">
      <h1 className='title'>THINGS TO DO</h1>
    
      <Box sx={{display:"flex",justifyContent:"center"}}>
          <TextField sx={{width:"50%",m:2, }}
                label="Enter New Task" 
                variant="outlined"
                value={input}
                onChange={handleChange}
          />
          <Button sx={{width:"15%",m:2,fontSize:25}}
                variant="contained" onClick={handleSubmit}>ADD TASK</Button>
      </Box>

      <Typography variant="h4" sx={{display:"flex",justifyContent:"center",fontWeight:"900"}}>
          Done : {doneCount}
      </Typography>
     {todolist}
    </div>
  );
}