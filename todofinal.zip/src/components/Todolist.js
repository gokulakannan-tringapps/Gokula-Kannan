import React from 'react'
import {Checkbox,Button,DialogActions,Grid,Typography,Box,Dialog,DialogTitle} from '@mui/material'
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';



function Todolist(props){

    const [open,setOpen]=React.useState(false)
    const [editable,setEditable]=React.useState(false)
    const [check,setCheck]=React.useState(false)
    const [lock,setLock]=React.useState(false)
    const [On, Off]=React.useState(false)

    const handleClickOpen = () =>{
        setOpen(true)
    }
    const handleClickClose = () =>{
        setOpen(false)
    }

    const handleEdit = () => {
        setEditable(!editable)
        Off(!On)
    }
    
    const handleCheckbox = () => {
        setCheck(!check)
        setLock(!lock)
       
    }
    return(
        
        <Box sx={{m:2,p:2, backgroundColor:"#c2de37"}}>
            <Grid container spacing={2} sx={{ml:5}}>
               <Grid sx={{display:"flex"}} item xs={4}>
               <Checkbox disabled={On} onClick={()=>{handleCheckbox(); props.status(check)} } />
               <Typography contentEditable={editable} variant="h4" sx={{textDecorationLine: check ? "line-through":" "}}>
                   {props.text}
               </Typography>
               </Grid>
               {!editable &&
               <>
               <Grid item xs={1} >
               <Button disabled={lock} sx={{mt:"2px",backgroundColor:"#e3293f"}} variant="contained" onClick={handleEdit}   ><EditIcon/></Button>
               </Grid>
               <Grid item xs={2}>
               <Button  disabled={lock} sx={{mt:"2px",backgroundColor:"#e3293f"}} variant="contained" onClick={handleClickOpen}><DeleteIcon/></Button>
               </Grid>
               </>
                }
                {editable &&    
               <Grid item xs={4}>
               <Button sx={{backgroundColor:"#e3293f"}} variant="contained" onClick={handleEdit}>Update</Button>
               </Grid>
                }
               
               <Dialog open={open} onClose={handleClickClose}>
                <DialogTitle>{"Are you sure to delete the selected list?"}</DialogTitle>
                <DialogActions>
                    <Button variant="contained" onClick={props.delete}>Delete</Button>
                    <Button variant="contained" onClick={handleClickClose} autoFocus>Cancel</Button>
                </DialogActions>
               </Dialog>
              
            </Grid> 
        </Box>
    )
}

export default Todolist;